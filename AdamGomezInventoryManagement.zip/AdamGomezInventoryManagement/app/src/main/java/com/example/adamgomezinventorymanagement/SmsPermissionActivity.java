package com.example.adamgomezinventorymanagement;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

/**
 * Displays the SMS permission screen for inventory alerts.
 * This screen allows the user to grant or deny SMS notification access.
 */
public class SmsPermissionActivity extends AppCompatActivity {

    private TextView tvPermissionStatus;

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    tvPermissionStatus.setText("SMS permission granted.");
                    Toast.makeText(this, "SMS permission granted.", Toast.LENGTH_SHORT).show();
                    sendLowStockAlert();
                } else {
                    tvPermissionStatus.setText("SMS permission denied.");
                    Toast.makeText(this, "SMS permission denied.", Toast.LENGTH_SHORT).show();
                }
                finish();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        Button btnAllowNotifications = findViewById(R.id.btnAllowNotifications);
        Button btnDenyNotifications = findViewById(R.id.btnDenyNotifications);
        tvPermissionStatus = findViewById(R.id.tvPermissionStatus);

        btnAllowNotifications.setOnClickListener(view -> requestSmsPermission());

        btnDenyNotifications.setOnClickListener(view -> {
            tvPermissionStatus.setText("User chose not to enable notifications.");
            Toast.makeText(
                    SmsPermissionActivity.this,
                    "Notifications declined.",
                    Toast.LENGTH_SHORT
            ).show();
            finish();
        });
    }

    /**
     * Requests SMS permission if it has not already been granted.
     */
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED) {
            tvPermissionStatus.setText("SMS permission already granted.");
            Toast.makeText(this, "SMS permission already granted.", Toast.LENGTH_SHORT).show();
            sendLowStockAlert();
            finish();
        } else {
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    /**
     * Sends a sample SMS inventory alert after permission is granted.
     * For emulator testing, 5554 is commonly used.
     */
    private void sendLowStockAlert() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "SMS permission is required to send alerts.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            String phoneNumber = "5554";
            String message = "Inventory Alert: An item is out of stock or needs restocking.";

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);

            Toast.makeText(this, "Inventory alert sent.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS could not be sent on this device.", Toast.LENGTH_SHORT).show();
        }
    }
}