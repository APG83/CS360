package com.example.adamgomezinventorymanagement;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Allows the user to add a new inventory item to the database.
 */
public class AddItemActivity extends AppCompatActivity {

    private EditText etItemName;
    private EditText etQuantity;
    private Button btnSaveItem;
    private Button btnCancel;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        databaseHelper = new DatabaseHelper(this);

        etItemName = findViewById(R.id.etItemName);
        etQuantity = findViewById(R.id.etQuantity);
        btnSaveItem = findViewById(R.id.btnSaveItem);
        btnCancel = findViewById(R.id.btnCancel);

        btnSaveItem.setOnClickListener(view -> saveItem());
        btnCancel.setOnClickListener(view -> finish());
    }

    /**
     * Validates user input and saves a new inventory item to the database.
     */
    private void saveItem() {
        String itemName = etItemName.getText() != null
                ? etItemName.getText().toString().trim()
                : "";

        String quantityText = etQuantity.getText() != null
                ? etQuantity.getText().toString().trim()
                : "";

        if (itemName.isEmpty() || quantityText.isEmpty()) {
            Toast.makeText(this, "Please complete all fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Quantity must be a number.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Your current add-item layout does not include a description field,
        // so an empty string is stored for now.
        boolean inserted = databaseHelper.addItem(itemName, quantity, "");

        if (inserted) {
            Toast.makeText(this, "Item added successfully.", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Could not add item.", Toast.LENGTH_SHORT).show();
        }
    }
}