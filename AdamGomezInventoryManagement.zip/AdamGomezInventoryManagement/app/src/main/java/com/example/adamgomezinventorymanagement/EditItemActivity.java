package com.example.adamgomezinventorymanagement;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditItemActivity extends AppCompatActivity {

    private EditText etEditItemName;
    private EditText etEditQuantity;
    private Button btnUpdateItem;
    private Button btnCancelEdit;
    private DatabaseHelper databaseHelper;
    private int itemId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        databaseHelper = new DatabaseHelper(this);

        etEditItemName = findViewById(R.id.etEditItemName);
        etEditQuantity = findViewById(R.id.etEditQuantity);
        btnUpdateItem = findViewById(R.id.btnUpdateItem);
        btnCancelEdit = findViewById(R.id.btnCancelEdit);

        if (etEditItemName == null || etEditQuantity == null || btnUpdateItem == null || btnCancelEdit == null) {
            Toast.makeText(this, "Edit screen layout mismatch.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        itemId = getIntent().getIntExtra("ITEM_ID", -1);

        if (itemId == -1) {
            Toast.makeText(this, "Invalid item selected.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadItem();

        btnUpdateItem.setOnClickListener(v -> updateItem());
        btnCancelEdit.setOnClickListener(v -> finish());
    }

    private void loadItem() {
        Cursor cursor = databaseHelper.getItemById(itemId);

        if (cursor != null && cursor.moveToFirst()) {
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow("item_name"));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));

            etEditItemName.setText(itemName);
            etEditQuantity.setText(String.valueOf(quantity));
            cursor.close();
        } else {
            if (cursor != null) {
                cursor.close();
            }
            Toast.makeText(this, "Item not found.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void updateItem() {
        String itemName = etEditItemName.getText() != null
                ? etEditItemName.getText().toString().trim()
                : "";

        String quantityText = etEditQuantity.getText() != null
                ? etEditQuantity.getText().toString().trim()
                : "";

        if (itemName.isEmpty() || quantityText.isEmpty()) {
            Toast.makeText(this, "Please complete all fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Quantity must be a number.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean updated = databaseHelper.updateItem(itemId, itemName, quantity, "");

        if (updated) {
            Toast.makeText(this, "Item updated successfully.", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Could not update item.", Toast.LENGTH_SHORT).show();
        }
    }
}