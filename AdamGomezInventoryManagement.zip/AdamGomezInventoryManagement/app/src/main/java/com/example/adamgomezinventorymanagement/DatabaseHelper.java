package com.example.adamgomezinventorymanagement;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Manages the SQLite database for user accounts and inventory items.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory_app.db";
    private static final int DATABASE_VERSION = 1;

    // Users table
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // Items table
    private static final String TABLE_ITEMS = "items";
    private static final String COLUMN_ITEM_ID = "item_id";
    private static final String COLUMN_ITEM_NAME = "item_name";
    private static final String COLUMN_ITEM_QUANTITY = "quantity";
    private static final String COLUMN_ITEM_DESCRIPTION = "description";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Creates the database tables the first time the app runs.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " ("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_USERNAME + " TEXT UNIQUE, "
                + COLUMN_PASSWORD + " TEXT)";

        String createItemsTable = "CREATE TABLE " + TABLE_ITEMS + " ("
                + COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_ITEM_NAME + " TEXT, "
                + COLUMN_ITEM_QUANTITY + " INTEGER, "
                + COLUMN_ITEM_DESCRIPTION + " TEXT)";

        db.execSQL(createUsersTable);
        db.execSQL(createItemsTable);
    }

    /**
     * Handles database upgrades if the schema changes.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(db);
    }

    /**
     * Registers a new user.
     *
     * @param username The username to save
     * @param password The password to save
     * @return true if successful, false if the user already exists or insert fails
     */
    public boolean registerUser(String username, String password) {
        if (userExists(username)) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    /**
     * Checks whether a username already exists in the database.
     *
     * @param username The username to check
     * @return true if found, otherwise false
     */
    public boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ?",
                new String[]{username}
        );

        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    /**
     * Validates a user's login credentials.
     *
     * @param username The username entered
     * @param password The password entered
     * @return true if the username and password match a record in the database
     */
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS
                        + " WHERE " + COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?",
                new String[]{username, password}
        );

        boolean isValid = cursor.moveToFirst();
        cursor.close();
        return isValid;
    }

    /**
     * Adds a new inventory item to the database.
     *
     * @param name The item name
     * @param quantity The item quantity
     * @param description The item description
     * @return true if the insert succeeds
     */
    public boolean addItem(String name, int quantity, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, name);
        values.put(COLUMN_ITEM_QUANTITY, quantity);
        values.put(COLUMN_ITEM_DESCRIPTION, description);

        long result = db.insert(TABLE_ITEMS, null, values);
        return result != -1;
    }

    /**
     * Retrieves all inventory items from the database.
     *
     * @return Cursor containing all item records
     */
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_ITEMS, null);
    }

    /**
     * Retrieves one inventory item by its ID.
     *
     * @param itemId The item ID to look up
     * @return Cursor containing the matching item
     */
    public Cursor getItemById(int itemId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT * FROM " + TABLE_ITEMS + " WHERE " + COLUMN_ITEM_ID + " = ?",
                new String[]{String.valueOf(itemId)}
        );
    }

    /**
     * Updates an existing inventory item.
     *
     * @param itemId The ID of the item to update
     * @param name The updated item name
     * @param quantity The updated item quantity
     * @param description The updated item description
     * @return true if at least one row was updated
     */
    public boolean updateItem(int itemId, String name, int quantity, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, name);
        values.put(COLUMN_ITEM_QUANTITY, quantity);
        values.put(COLUMN_ITEM_DESCRIPTION, description);

        int rowsAffected = db.update(
                TABLE_ITEMS,
                values,
                COLUMN_ITEM_ID + " = ?",
                new String[]{String.valueOf(itemId)}
        );

        return rowsAffected > 0;
    }

    /**
     * Deletes an inventory item by its ID.
     *
     * @param itemId The ID of the item to delete
     * @return true if a row was deleted
     */
    public boolean deleteItem(int itemId) {
        SQLiteDatabase db = this.getWritableDatabase();

        int rowsDeleted = db.delete(
                TABLE_ITEMS,
                COLUMN_ITEM_ID + " = ?",
                new String[]{String.valueOf(itemId)}
        );

        return rowsDeleted > 0;
    }
}
