package com.example.adamgomezinventorymanagement;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Displays the inventory dashboard screen.
 * Loads inventory items from the SQLite database and displays them in a table.
 */
public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private TableLayout tableInventory;
    private Button btnAddItem;
    private Button btnNotifications;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new DatabaseHelper(this);

        tableInventory = findViewById(R.id.tableInventory);
        btnAddItem = findViewById(R.id.btnAddItem);
        btnNotifications = findViewById(R.id.btnNotifications);

        btnAddItem.setOnClickListener(view ->
                startActivity(new Intent(InventoryActivity.this, AddItemActivity.class))
        );

        btnNotifications.setOnClickListener(view ->
                startActivity(new Intent(InventoryActivity.this, SmsPermissionActivity.class))
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadInventory();
    }

    /**
     * Loads all inventory items from the database and rebuilds the table rows.
     */
    private void loadInventory() {
        int childCount = tableInventory.getChildCount();
        if (childCount > 1) {
            tableInventory.removeViews(1, childCount - 1);
        }

        Cursor cursor = databaseHelper.getAllItems();

        if (cursor == null || cursor.getCount() == 0) {
            TableRow emptyRow = new TableRow(this);

            TextView emptyText = new TextView(this);
            emptyText.setText("No inventory items found.");
            emptyText.setPadding(8, 16, 8, 16);

            emptyRow.addView(emptyText);
            tableInventory.addView(emptyRow);

            if (cursor != null) {
                cursor.close();
            }
            return;
        }

        while (cursor.moveToNext()) {
            int itemId = cursor.getInt(cursor.getColumnIndexOrThrow("item_id"));
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow("item_name"));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));

            String status;
            int statusColor;

            if (quantity == 0) {
                status = "Out of Stock";
                statusColor = 0xFFDC2626;
            } else if (quantity < 5) {
                status = "Low Stock";
                statusColor = 0xFFB45309;
            } else {
                status = "In Stock";
                statusColor = 0xFF15803D;
            }

            TableRow row = new TableRow(this);
            row.setPadding(0, 8, 0, 8);

            TextView tvName = new TextView(this);
            tvName.setText(itemName);
            tvName.setTextColor(0xFF1F2937);
            tvName.setPadding(8, 8, 8, 8);

            TextView tvQty = new TextView(this);
            tvQty.setText(String.valueOf(quantity));
            tvQty.setTextColor(0xFF1F2937);
            tvQty.setPadding(8, 8, 8, 8);

            TextView tvStatus = new TextView(this);
            tvStatus.setText(status);
            tvStatus.setTextColor(statusColor);
            tvStatus.setPadding(8, 8, 8, 8);

            Button btnEdit = new Button(this);
            btnEdit.setText("Edit");
            btnEdit.setOnClickListener(v -> openEditItem(itemId));

            Button btnDelete = new Button(this);
            btnDelete.setText("Delete");
            btnDelete.setOnClickListener(v -> deleteItem(itemId, itemName));

            row.addView(tvName);
            row.addView(tvQty);
            row.addView(tvStatus);
            row.addView(btnEdit);
            row.addView(btnDelete);

            tableInventory.addView(row);
        }

        cursor.close();
    }

    /**
     * Opens the edit screen for the selected inventory item.
     *
     * @param itemId The database ID of the item
     */
    private void openEditItem(int itemId) {
        Intent intent = new Intent(InventoryActivity.this, EditItemActivity.class);
        intent.putExtra("ITEM_ID", itemId);
        startActivity(intent);
    }

    /**
     * Deletes an inventory item and refreshes the table.
     *
     * @param itemId The database ID of the item
     * @param itemName The item name for user feedback
     */
    private void deleteItem(int itemId, String itemName) {
        boolean deleted = databaseHelper.deleteItem(itemId);

        if (deleted) {
            Toast.makeText(this, itemName + " deleted.", Toast.LENGTH_SHORT).show();
            loadInventory();
        } else {
            Toast.makeText(this, "Could not delete " + itemName + ".", Toast.LENGTH_SHORT).show();
        }
    }
}
