package com.example.adamgomezinventorymanagement;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Main login screen for the Inventory Management app.
 * Allows existing users to log in and new users to create an account.
 */
public class MainActivity extends AppCompatActivity {

    private EditText etUsername;
    private EditText etPassword;
    private Button btnLogin;
    private Button btnCreateAccount;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Link XML views to Java variables
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Disable buttons until both fields contain text
        btnLogin.setEnabled(false);
        btnCreateAccount.setEnabled(false);

        // Watch both text fields so buttons only enable when input is present
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Not needed for this app
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateButtonState();
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Not needed for this app
            }
        };

        etUsername.addTextChangedListener(textWatcher);
        etPassword.addTextChangedListener(textWatcher);

        // Log in existing user
        btnLogin.setOnClickListener(v -> loginUser());

        // Create a new account
        btnCreateAccount.setOnClickListener(v -> registerUser());
    }

    /**
     * Enables buttons only when both username and password fields have text.
     */
    private void updateButtonState() {
        String username = etUsername.getText() != null
                ? etUsername.getText().toString().trim()
                : "";

        String password = etPassword.getText() != null
                ? etPassword.getText().toString().trim()
                : "";

        boolean hasInput = !username.isEmpty() && !password.isEmpty();
        btnLogin.setEnabled(hasInput);
        btnCreateAccount.setEnabled(hasInput);
    }

    /**
     * Logs in a user if the username and password match a saved account.
     */
    private void loginUser() {
        String username = etUsername.getText() != null
                ? etUsername.getText().toString().trim()
                : "";

        String password = etPassword.getText() != null
                ? etPassword.getText().toString().trim()
                : "";

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean isValidUser = databaseHelper.validateUser(username, password);

        if (isValidUser) {
            Toast.makeText(this, "Login successful.", Toast.LENGTH_SHORT).show();

            // Change InventoryActivity to your real next screen if needed
            Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Registers a new user if the username does not already exist.
     */
    private void registerUser() {
        String username = etUsername.getText() != null
                ? etUsername.getText().toString().trim()
                : "";

        String password = etPassword.getText() != null
                ? etPassword.getText().toString().trim()
                : "";

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean isRegistered = databaseHelper.registerUser(username, password);

        if (isRegistered) {
            Toast.makeText(this, "Account created successfully. You can now log in.", Toast.LENGTH_SHORT).show();
            etUsername.setText("");
            etPassword.setText("");
        } else {
            Toast.makeText(this, "Username already exists. Please choose another.", Toast.LENGTH_SHORT).show();
        }
    }
}